import { parse } from "./geojson-parse.js";

/**
 * geojson-modern — site scripts
 * Two independent features, each isolated in its own init function:
 *   1. Copy-to-clipboard for the install command.
 *   2. Live playground that runs the real parse() against user input.
 */

const SAMPLE_DATA = [
  { name: "Café Aurora", category: "Cafetería", lat: 40.4168, lng: -3.7038 },
  { name: "Parque Norte", category: "Parque", lat: 40.4268, lng: -3.7138 },
  { name: "Estación Sur", category: "Transporte", lat: 40.4068, lng: -3.6938 },
];

const SAMPLE_LINE = [{ name: "Ruta matinal", line: [[40.41, -3.70], [40.42, -3.71], [40.43, -3.69]] }];

const SAMPLE_POLYGON = [
  {
    name: "Zona centro",
    polygon: [[[40.41, -3.70], [40.42, -3.70], [40.42, -3.71], [40.41, -3.71], [40.41, -3.70]]],
  },
];

function debounce(fn, delay) {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
}

/* -------------------------------------------------------
   1. Copy-to-clipboard
   ------------------------------------------------------- */
function initCopyButtons() {
  const buttons = document.querySelectorAll("[data-copy-target]");

  for (const button of buttons) {
    button.addEventListener("click", async () => {
      const text = button.getAttribute("data-copy-target");
      try {
        await navigator.clipboard.writeText(text);
        button.classList.add("is-copied");
        setTimeout(() => button.classList.remove("is-copied"), 1500);
      } catch {
        // Clipboard API unavailable (e.g. insecure context) — fail silently,
        // the command is still selectable/copyable by hand.
      }
    });
  }
}

/* -------------------------------------------------------
   2. Live playground
   ------------------------------------------------------- */
function initPlayground() {
  const input = document.getElementById("pg-input");
  const output = document.getElementById("pg-output-code");
  const errorEl = document.getElementById("pg-error");
  const geomType = document.getElementById("pg-geom-type");
  const pointFields = document.getElementById("pg-point-fields");
  const attrField = document.getElementById("pg-attr-field");
  const latAttr = document.getElementById("pg-lat-attr");
  const lngAttr = document.getElementById("pg-lng-attr");
  const attr = document.getElementById("pg-attr");

  if (!input || !output) return; // playground not present on this page

  function currentParams() {
    const type = geomType.value;
    if (type === "Point") {
      return { Point: [latAttr.value.trim() || "lat", lngAttr.value.trim() || "lng"] };
    }
    return { [type]: attr.value.trim() || "line" };
  }

  function updateFieldVisibility() {
    const isPoint = geomType.value === "Point";
    pointFields.classList.toggle("pg-field--hidden", !isPoint);
    attrField.classList.toggle("pg-field--hidden", isPoint);
  }

  function loadSampleForType() {
    const type = geomType.value;
    if (type === "Point") input.value = JSON.stringify(SAMPLE_DATA, null, 2);
    else if (type === "LineString") input.value = JSON.stringify(SAMPLE_LINE, null, 2);
    else if (type === "Polygon") input.value = JSON.stringify(SAMPLE_POLYGON, null, 2);
    attr.value = type === "Polygon" ? "polygon" : "line";
  }

  function run() {
    errorEl.textContent = "";
    let data;

    try {
      data = JSON.parse(input.value);
    } catch {
      errorEl.textContent = "El JSON de entrada no es válido.";
      return;
    }

    try {
      const result = parse(data, { ...currentParams(), removeInvalidGeometries: true });
      output.textContent = JSON.stringify(result, null, 2);
    } catch (error) {
      errorEl.textContent = error instanceof Error ? error.message : "No se pudo convertir.";
    }
  }

  const debouncedRun = debounce(run, 200);

  input.addEventListener("input", debouncedRun);
  latAttr.addEventListener("input", debouncedRun);
  lngAttr.addEventListener("input", debouncedRun);
  attr.addEventListener("input", debouncedRun);
  geomType.addEventListener("change", () => {
    updateFieldVisibility();
    loadSampleForType();
    run();
  });

  // Initial state
  updateFieldVisibility();
  loadSampleForType();
  run();
}

document.addEventListener("DOMContentLoaded", () => {
  initCopyButtons();
  initPlayground();
});
