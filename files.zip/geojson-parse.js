/**
 * Browser copy of geojson-modern's core parser.
 * Kept in sync with ../../src/index.js from the library package.
 * Used only to power the live playground demo on this site.
 */

const GEOMETRY_TYPES = [
  "Point",
  "MultiPoint",
  "LineString",
  "MultiLineString",
  "Polygon",
  "MultiPolygon",
];

function isNil(value) {
  return value === null || value === undefined;
}

function toCoordPair(pair) {
  if (Array.isArray(pair)) {
    const [lat, lng] = pair;
    return [lng, lat];
  }
  if (pair && typeof pair === "object") {
    const lat = pair.lat ?? pair.latitude ?? pair.y;
    const lng = pair.lng ?? pair.lon ?? pair.long ?? pair.longitude ?? pair.x;
    return [lng, lat];
  }
  throw new TypeError(`Cannot convert value to a coordinate pair: ${JSON.stringify(pair)}`);
}

const coordinateBuilders = {
  Point(item, attr) {
    const [latAttr, lngAttr] = attr;
    return [item[lngAttr], item[latAttr]];
  },
  MultiPoint(item, attr) {
    return item[attr].map(toCoordPair);
  },
  LineString(item, attr) {
    return item[attr].map(toCoordPair);
  },
  MultiLineString(item, attr) {
    return item[attr].map((line) => line.map(toCoordPair));
  },
  Polygon(item, attr) {
    return item[attr].map((ring) => ring.map(toCoordPair));
  },
  MultiPolygon(item, attr) {
    return item[attr].map((poly) => poly.map((ring) => ring.map(toCoordPair)));
  },
};

function attrsForType(type, attr) {
  return type === "Point" ? attr : [attr];
}

function isGeometryPresent(item, type, attr) {
  const attrs = attrsForType(type, attr);
  return attrs.every((key) => !isNil(item[key]));
}

function detectGeometry(item, params) {
  for (const type of GEOMETRY_TYPES) {
    const attr = params[type];
    if (isNil(attr)) continue;
    if (isGeometryPresent(item, type, attr)) {
      return { type, attr };
    }
  }
  return null;
}

function buildProperties(item, params, geometryAttrs) {
  const { include, exclude, extra } = params;
  let properties;

  if (Array.isArray(include)) {
    properties = {};
    for (const key of include) properties[key] = item[key];
  } else {
    properties = {};
    for (const key of Object.keys(item)) {
      if (geometryAttrs.includes(key)) continue;
      if (Array.isArray(exclude) && exclude.includes(key)) continue;
      properties[key] = item[key];
    }
  }

  if (typeof extra === "function") {
    Object.assign(properties, extra(item));
  } else if (extra && typeof extra === "object") {
    Object.assign(properties, extra);
  }

  return properties;
}

function extendBbox(bbox, coordinates) {
  const stack = [coordinates];
  while (stack.length) {
    const value = stack.pop();
    if (Array.isArray(value[0])) {
      stack.push(...value);
      continue;
    }
    const [x, y] = value;
    if (x < bbox[0]) bbox[0] = x;
    if (y < bbox[1]) bbox[1] = y;
    if (x > bbox[2]) bbox[2] = x;
    if (y > bbox[3]) bbox[3] = y;
  }
  return bbox;
}

function itemToFeature(item, params) {
  const detected = detectGeometry(item, params);

  if (!detected) {
    if (params.removeInvalidGeometries) return null;
    throw new Error(`Unable to detect a geometry for item: ${JSON.stringify(item)}`);
  }

  const { type, attr } = detected;
  const coordinates = coordinateBuilders[type](item, attr);
  const geometryAttrs = attrsForType(type, attr);
  const properties = buildProperties(item, params, geometryAttrs);

  const feature = {
    type: "Feature",
    geometry: { type, coordinates },
    properties,
  };

  if (params.bbox) {
    feature.bbox = extendBbox([Infinity, Infinity, -Infinity, -Infinity], coordinates);
  }

  return feature;
}

export function parse(data, params = {}) {
  const items = Array.isArray(data) ? data : [data];

  const features = items
    .map((item) => itemToFeature(item, params))
    .filter((feature) => feature !== null);

  const featureCollection = { type: "FeatureCollection", features };

  if (params.crs) featureCollection.crs = params.crs;

  if (params.bbox) {
    featureCollection.bbox = features.reduce(
      (acc, feature) => extendBbox(acc, feature.geometry.coordinates),
      [Infinity, Infinity, -Infinity, -Infinity],
    );
  }

  if (params.extraGlobal) featureCollection.properties = { ...params.extraGlobal };

  return featureCollection;
}
